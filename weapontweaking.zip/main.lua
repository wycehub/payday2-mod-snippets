Hooks:PostHook( WeaponTweakData, "init", "weapontweaking", function(self)
    --your code goes here
    self.new_mp5.stats.damage = 69--example, can be deleted
    self.mosin.stats.damage = 420--example, can be deleted


end )
[[
self.(id).CLIP_AMMO_MAX = (int)
self.(id).AMMO_MAX = (int)
self.(id).fire_mode_data.fire_rate = 60 / (int)
self.(id).stats.damage = (int)
self.(id).stats.spread = (int)
self.(id).stats.recoil = (int)
self.(id).stats.suppression = (int)
self.(id).stats.concealment = (int)
self.(id).stats.reload = (int)  --11 is base
self.(id).stats_modifiers = {damage = (int)}
self.(id).AMMO_PICKUP = {(int), (int)}  --min to max
self.(id).can_shoot_through_enemy = (bool)
self.(id).can_shoot_through_wall = (bool)
self.(id).can_shoot_through_shield = (bool)
self.(id).armor_piercing_chance = (bool)

grab line with stat to edit, replace (id) = id from link below, (int) = number, (bool) = true/false
(id)s: https://wiki.modworkshop.net/books/payday-2-mod-creation/page/weapons]]
