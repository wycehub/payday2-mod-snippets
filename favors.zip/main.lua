function PrePlanningManager:get_current_budget()
    return 0, 69
end
